from fang.graphsage.walker import GraphSageWalker
from fang.config import FangConfig
from fang.dataset import FangGraphSageDataset
from fang.graphsage.models import FangGraphSage, StanceClassifier, FakeNewsClassifier
from sklearn.utils import shuffle
from training.configs import BasicConfig
import math
from tqdm import tqdm
import time
import pandas as pd
from sklearn.cluster import DBSCAN, KMeans
from sklearn import metrics
from sklearn.metrics import v_measure_score
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from torch.utils.tensorboard import SummaryWriter
from training.evaluator import Evaluator
from training.utils import *
from fang.utils import *
from scipy.spatial.distance import cosine
import random
from collections import Counter


AGG_FUNC = "MEAN"
USE_GCN = False
UNSUP_LOSS = "normal"
STANCE_HIDDEN_DIM = 4
N_SAGE_LAYERS = 1
TOP_USER_PER_NEWS = 3
TOP_USER_PER_BATCH = 100

EXPORT_EMBEDDING = True

def load_single(run_config: BasicConfig, fang_config: FangConfig, is_community):
    device = torch.device("cuda:0" if run_config.use_cuda else "cpu")
    data = FangGraphSageDataset(fang_config, is_community)
    meta_data = load_meta(fang_config)

    features = torch.FloatTensor(data.feature_data).to(device)
    embed_size = fang_config.n_hidden
    adj_lists = data.adj_lists  # default dictionary int->set(int) {0: {1, 2}}
    edge_list = data.edge_list
    stance_lists = data.stance_lists
    n_stances = data.n_stances
    n_news_labels = data.n_news_labels
    news_labels = data.news_labels
    dev_nodes, test_nodes = set(data.dev_idxs), set(data.test_idxs)
    news, users, sources = data.news, data.users, data.sources
    n_nodes, input_size = features.size(0), features.size(1)
    return device, data, meta_data, features, embed_size, adj_lists, edge_list, stance_lists, n_stances, n_news_labels, news_labels, \
        dev_nodes, test_nodes, news, users, sources, n_nodes, input_size


def test_fn(run_config, fang_config, data, model_dir, features, n_stances, n_news_labels, input_size, embed_size,
            temporal, attention, device, step, n_nodes, dev_nodes, test_nodes, adj_lists, stance_lists,
            news, users, sources, news_labels):
    graph_sage, stance_classifier, news_classifier = load_save_models(fang_config, data, model_dir, features, n_stances,
                                                                      n_news_labels, input_size, embed_size,
                                                                      temporal, attention, device, step)
    # for train nodes, we add all nodes that are not dev and test nodes
    train_nodes = [x for x in range(n_nodes) if x not in dev_nodes and x not in test_nodes]
    graph_sage_walker = GraphSageWalker(adj_lists, stance_lists, news, users, sources,
                                        (set(train_nodes), dev_nodes, test_nodes),
                                        news_labels, device, max_engages=100)

    test_evaluator, output_attention = eval_fn(test_nodes, graph_sage_walker, graph_sage, news_classifier,
                                               n_stances, embed_size,
                                               run_config.metrics, 0, None, device, tag="test", return_attn=True)


def load_save_models(fang_config, data, model_dir, features, n_stances, n_news_labels, input_size, embed_size,
                     temporal, attention, device, step=-1):
    step = step if step != -1 else "best"
    graph_sage_model_path = os.path.join(model_dir, "graph_sage_ckpt_{}.tar".format(step))
    print("Load model with path {}".format(graph_sage_model_path))
    graph_sage = FangGraphSage(fang_config.n_layers, input_size, embed_size,
                               features, data.adj_lists, device, n_sage_layer=N_SAGE_LAYERS, gcn=USE_GCN,
                               agg_func=AGG_FUNC)
    graph_sage.load_state_dict(torch.load(graph_sage_model_path)["state_dict"])
    graph_sage = graph_sage.to(device)

    stance_classifier_model_path = os.path.join(model_dir, "stance_classifier_ckpt_{}.tar".format(step))
    stance_classifier = StanceClassifier(embed_size, n_stances, STANCE_HIDDEN_DIM)
    stance_classifier.load_state_dict(torch.load(stance_classifier_model_path)["state_dict"])
    stance_classifier = stance_classifier.to(device)

    news_classifier_model_path = os.path.join(model_dir, "news_classifier_ckpt_{}.tar".format(step))
    news_classifier = FakeNewsClassifier(embed_size, int(fang_config.n_hidden/2), n_stances, 2, n_news_labels,
                                         temporal, attention, fang_config.dropout)
    news_classifier.load_state_dict(torch.load(news_classifier_model_path)["state_dict"])
    news_classifier = news_classifier.to(device)
    return graph_sage, stance_classifier, news_classifier


def test_fang_graph_sage(exp_name, model_dir, step, run_config: BasicConfig, fang_config: FangConfig, is_community,
                         temporal, attention, analysis):
    writer = SummaryWriter(os.path.join(run_config.log_dir, exp_name))
    device, data, meta_data, features, embed_size, adj_lists, edge_list, stance_lists, n_stances, n_news_labels, news_labels, \
        dev_nodes, test_nodes, news, users, sources, n_nodes, input_size = \
        load_single(run_config, fang_config, is_community)
    graph_sage, stance_classifier, news_classifier = load_save_models(fang_config, data, model_dir, features, n_stances, n_news_labels, input_size, embed_size,
        temporal, attention, device, step)

    # for train nodes, we add all nodes that are not dev and test nodes
    train_nodes = [x for x in range(n_nodes) if x not in dev_nodes and x not in test_nodes]

    graph_sage_walker = GraphSageWalker(adj_lists, stance_lists, news, users, sources,
                                        (set(train_nodes), dev_nodes, test_nodes),
                                        news_labels, device, fang_config.cache_path, data.entities, max_engages=100)

    if analysis == "":
        test_evaluator, output_attention = eval_fn(test_nodes, graph_sage_walker, graph_sage, news_classifier,
                                                   n_stances, embed_size,
                                                   run_config.metrics, 0, None, device, tag="test", return_attn=True)

    elif analysis == "embedding":
        # TODO: Refactor this duplicated codes
        meta_header = meta_data[0]
        meta_body = meta_data[1:]

        def infer_news_emb(_news_batch):
            st = time.time()
            _news_sources_emb_batch, _news_emb_batch, _news_user_emb_batch, _news_stances_tensor, \
            _news_ts_tensor, _news_labels_tensor, _masked_attn_batch, _news_labels_batch, _engage_users_batch = \
                preprocess_news_classification_data(graph_sage, graph_sage_walker, _news_batch, n_stances,
                                                    embed_size, device, return_user_batch=True)
            _news_logit_batch, _news_attention, _news_emb_batch = news_classifier(
                _news_emb_batch, _news_sources_emb_batch, _news_user_emb_batch, _news_stances_tensor,
                _news_ts_tensor, _masked_attn_batch)
            # print("Infer {} news emb for: {:.4f}s".format(len(_news_batch), time.time() - st))
            return _news_logit_batch, _news_attention, _news_emb_batch, _news_labels_tensor, _engage_users_batch

        all_nodes = list(news) + list(sources)
        print("Exporting train embeddings")
        export_batch_size = run_config.batch_size * 8
        all_node_embed, export_buffer = [], []
        all_node_meta = []
        for node in tqdm(all_nodes, desc="Exporting node embedding to Tensorboard"):
            export_buffer.append(node)
            if len(export_buffer) == export_batch_size:
                # split the buffer into news and none news entities
                export_news = [n for n in export_buffer if n in graph_sage_walker.news_labels]
                export_not_news = [n for n in export_buffer if n not in graph_sage_walker.news_labels]
                if len(export_news) > 0:
                    _, _, buffer_news_emb, _, _ = infer_news_emb(
                        export_news)
                    buffer_news_emb = buffer_news_emb.detach().cpu().numpy()
                    all_node_embed.extend(list(buffer_news_emb))
                    all_node_meta.extend([meta_body[node] for node in export_news])
                    del buffer_news_emb
                if len(export_not_news) > 0:
                    buffer_node_emb = graph_sage(export_not_news).detach().cpu().numpy()
                    all_node_embed.extend(list(buffer_node_emb))
                    all_node_meta.extend([meta_body[node] for node in export_not_news])
                    del buffer_node_emb
                export_buffer = []

        # export last buffer
        if len(export_buffer) > 0:
            export_news = [n for n in export_buffer if n in graph_sage_walker.news_labels]
            export_not_news = [n for n in export_buffer if n not in graph_sage_walker.news_labels]
            if len(export_news) > 0:
                _, _, buffer_news_emb, _, _ = infer_news_emb(
                    export_news)
                buffer_news_emb = buffer_news_emb.detach().cpu().numpy()
                all_node_embed.extend(list(buffer_news_emb))
                all_node_meta.extend([meta_body[node] for node in export_news])
            if len(export_not_news) > 0:
                buffer_node_emb = graph_sage(export_not_news).detach().cpu().numpy()
                all_node_embed.extend(list(buffer_node_emb))
                all_node_meta.extend([meta_body[node] for node in export_not_news])

        all_node_embed = np.vstack(all_node_embed)
        writer.add_embedding(all_node_embed, tag='node embedding', metadata=all_node_meta,
                             global_step=0, metadata_header=meta_header)
        del all_node_embed

    elif analysis == "attention":
        test_evaluator, output_attention = eval_fn(news, graph_sage_walker, graph_sage, news_classifier,
                                                   n_stances, embed_size,
                                                   run_config.metrics, 0, None, device, tag="test", return_attn=True)

        predictions = test_evaluator.predictions
        labels = test_evaluator.labels

        cpu_attention = output_attention.detach().cpu().numpy()
        max_duration = 86400 * 14   # 2 weeks
        cutoff_step = 3600 * 12  # cutoff step = 3 hours
        n_bins = int(max_duration / cutoff_step)
        source_batch, news_batch, engage_users_batch, engage_stances_batch, engage_ts_batch, masked_attn_batch, news_labels_batch = \
            graph_sage_walker.fetch_news_classification(test_nodes, n_stances, None, max_duration)
        real_attn_dist, fake_attn_dist = [], []
        for i, engage_ts in tqdm(enumerate(engage_ts_batch), desc="Analyzing attention"):     # iterating through each example
            attn_bin = np.zeros(n_bins)
            non_zero_bins = 0
            for j, ts in enumerate(engage_ts):
                if ts[0] > 0:
                    ts_mean = (ts[0] - 1e-8)*max_duration
                    bin_idx = min(int(ts_mean/cutoff_step), n_bins-1)
                    attn_bin[bin_idx] += cpu_attention[i][j]
                    if ts[0] > 1e-8:
                        non_zero_bins += 1
            attn_bin *= non_zero_bins
            if predictions[i] == 1:
                real_attn_dist.append(attn_bin)
            else:
                fake_attn_dist.append(attn_bin)
        real_attn = np.mean(real_attn_dist, axis=0)
        fake_attn = np.mean(fake_attn_dist, axis=0)
        all_real_attn = [real_attn[0], np.sum(real_attn[1:4]), np.sum(real_attn[4:-1]), real_attn[-1]]
        all_fake_attn = [fake_attn[0], np.sum(fake_attn[1:4]), np.sum(fake_attn[4:-1]), fake_attn[-1]]
        print("First 12h real attention {}".format(all_real_attn[0] / np.sum(all_real_attn)))
        print("12h - 36h real attention {}".format(all_real_attn[1] / np.sum(all_real_attn)))
        print("36h - 2 weeks real attention {}".format(all_real_attn[2] / np.sum(all_real_attn)))
        print("2 weeks+ real attention {}".format(all_real_attn[3] / np.sum(all_real_attn)))
        print("First 12h fake attention {}".format(all_fake_attn[0] / np.sum(all_fake_attn)))
        print("12h - 36h fake attention {}".format(all_fake_attn[1] / np.sum(all_fake_attn)))
        print("36h - 2 weeks fake attention {}".format(all_fake_attn[2] / np.sum(all_fake_attn)))
        print("2 weeks+ fake attention {}".format(all_fake_attn[3] / np.sum(all_fake_attn)))


def run_fang_graph_sage(exp_name, run_config: BasicConfig, fang_config: FangConfig, is_community,
                        temporal, attention, use_stance, use_proximity, pretrained_dir="", pretrained_step=-1):
    device, data, meta_data, features, embed_size, adj_lists, edge_list, stance_lists, n_stances, n_news_labels, \
        news_labels, dev_nodes, test_nodes, news, users, sources, n_nodes, input_size = \
        load_single(run_config, fang_config, is_community)
    train_fn(run_config, fang_config, meta_data, exp_name, dev_nodes, test_nodes,
             embed_size, features, data, device, n_stances, n_news_labels,
             adj_lists, stance_lists, news, users, sources, news_labels, temporal, attention, use_stance, use_proximity,
             n_nodes, input_size, pretrained_dir, pretrained_step)


def train_fn(run_config: BasicConfig, fang_config: FangConfig, meta_data, exp_name, dev_nodes, test_nodes,
             embed_size, features, data, device, n_stances, n_news_labels,
             adj_lists, stance_lists, news, users, sources, news_labels, temporal, attention, use_stance, use_proximity,
             n_nodes, input_size, pretrained_dir="", pretrained_step=-1):

    all_nodes = shuffle(list(range(n_nodes)))
    # for train nodes, we add all nodes that are not dev and test nodes
    train_nodes = [x for x in range(n_nodes) if x not in dev_nodes and x not in test_nodes]

    # my part starts here

    writer = SummaryWriter(os.path.join(run_config.log_dir, exp_name))

    meta_header = meta_data[0]
    meta_body = meta_data[1:]
    writer.add_embedding(features, tag='node embedding', metadata=meta_data[1:],
                         global_step=0, metadata_header=meta_data[0])

    best_evaluator, best_output_path_dicts = Evaluator(logits=None, labels=None), {}
    graph_sage_walker = GraphSageWalker(adj_lists, stance_lists, news, users, sources,
                                        (set(train_nodes), dev_nodes, test_nodes),
                                        news_labels, device, fang_config.cache_path, data.entities)

    graph_sage = FangGraphSage(fang_config.n_layers, input_size, embed_size,
                                   features, data.adj_lists, device, n_sage_layer=N_SAGE_LAYERS, gcn=USE_GCN,
                                   agg_func=AGG_FUNC)

    news_classifier = FakeNewsClassifier(embed_size, int(fang_config.n_hidden/2), n_stances, 2, n_news_labels,
                                             temporal, attention, fang_config.dropout)
    
    def infer_news_emb(_news_batch):
        st = time.time()
        _news_sources_emb_batch, _news_emb_batch, _news_user_emb_batch, _news_stances_tensor, \
        _news_ts_tensor, _news_labels_tensor, _masked_attn_batch, _news_labels_batch, _engage_users_batch = \
            preprocess_news_classification_data(graph_sage, graph_sage_walker, _news_batch, n_stances,
                                                embed_size, device, return_user_batch=True)
        _news_logit_batch, _news_attention, _news_emb_batch = news_classifier(
                    _news_emb_batch, _news_sources_emb_batch, _news_user_emb_batch, _news_stances_tensor,
                    _news_ts_tensor, _masked_attn_batch)
        # print("Infer {} news emb for: {:.4f}s".format(len(_news_batch), time.time() - st))
        return _news_logit_batch, _news_attention, _news_emb_batch, _news_labels_tensor, _engage_users_batch

    def extract_most_attended_users(_news_attn, _engage_users):
        if _news_attn is not None:
            top_attn_users = set()
            _news_attn = _news_attn.detach().cpu().numpy()
            attn_sorted_args = np.argsort(_news_attn)
            top_args = attn_sorted_args[:, -TOP_USER_PER_NEWS:]
            for i, news_engaged_users in enumerate(_engage_users):
                attn_args = top_args[i]
                for idx in attn_args:
                    if idx < len(news_engaged_users):
                        top_attn_users.add(news_engaged_users[idx])
        else:
            all_engaged_users = []
            for i, news_engaged_users in enumerate(_engage_users):
                all_engaged_users.extend(news_engaged_users)
            user_cnt = Counter(all_engaged_users)
            most_common_users = user_cnt.most_common()
            top_attn_users = set([u[0] for u in most_common_users])
        return top_attn_users

    all_models = [graph_sage, news_classifier]

    params = []
    for model in all_models:
        for param in model.parameters():
            if param.requires_grad:
                params.append(param)

    print("Initialize optimizer with weight decay {}".format(run_config.weight_decay))
    optimizer = torch.optim.Adam(params, weight_decay=run_config.weight_decay)
    optimizer.zero_grad()
    for model in all_models:
        model.zero_grad()
        model.to(device)
        model.train()

    b_sz = run_config.batch_size
    train_node_set = set(train_nodes)
    log_every = run_config.inform_every_batch_num
    eval_every_epoch = run_config.eval_every_epoch_num

    global_step, sampling_time, modeling_time = 0, 0., 0.

    _news_losses = []

    news_nodes = list(news)
    n_nodes = len(news_nodes)
    n_batch_per_epoch = math.ceil(n_nodes / float(b_sz))

    for epoch in tqdm(range(run_config.epoch_num), desc="Next Epoch"):
        graph_sage.train()
        random.shuffle(news_nodes)
        
        for batch_idx in tqdm(range(n_batch_per_epoch), desc="Sampling news batches"):
            news_loss = None
            graph_sage_walker.reset()
            news_node_batch = news_nodes[batch_idx * b_sz:(batch_idx + 1) * b_sz]
            news_batch = [n for n in news_node_batch if n in train_node_set]
            if len(news_batch) > 0:
                news_emb_batch = graph_sage(news_batch) if len(news_batch) > 0 else None
                news_logit_batch, train_news_attn, news_emb_batch, news_labels_tensor, train_engage_users = infer_news_emb(news_batch)
                news_loss = graph_sage_walker.compute_news_loss(news_logit_batch, news_labels_tensor)

            
            if news_loss is None:
                print("Skipping batch. No news loss is computed.")
                continue
    
            news_loss.backward()
            if run_config.max_grad_norm is not None:
                torch.nn.utils.clip_grad_norm_(params, run_config.max_grad_norm)
            total_grad = 0
            for name, param in list(filter(lambda p: p[1].grad is not None, graph_sage.named_parameters())):
                param_grad = param.grad.data.norm(2).item()
                total_grad += param_grad

            optimizer.step()

            optimizer.zero_grad()
            for model in all_models:
                model.zero_grad()

            if news_loss is not None:
                _news_losses.append(float(news_loss.detach().cpu()))
            
            if global_step % log_every == 0:
                news_loss_val = np.mean(_news_losses) if len(_news_losses) > 0 else None
                _news_losses = []
                train_results = {
                    "grad": total_grad
                }
                if news_loss_val is not None:
                    train_results["news_loss"] = news_loss_val
                writer.add_scalars("train", train_results, global_step)
                print(train_results)
            global_step += 1
        graph_sage_walker.save()

        if epoch % eval_every_epoch == 0:
             if True:
                # Log nodes to tensorboard
                if meta_data is not None and EXPORT_EMBEDDING:
                    print("Exporting train embeddings")
                    export_batch_size = run_config.batch_size * 8
                    all_node_embed, export_buffer = [], []
                    all_node_meta = []
                    for node in tqdm(news_nodes, desc="Exporting node embedding to Tensorboard"):
                        export_buffer.append(node)
                        if len(export_buffer) == export_batch_size:
                            # split the buffer into news and none news entities
                            export_news = [n for n in export_buffer if n in graph_sage_walker.news_labels]
                            #export_not_news = [n for n in export_buffer if n not in graph_sage_walker.news_labels]
                            if len(export_news) > 0:
                                _, _, buffer_news_emb, _, _ = infer_news_emb(
                                    export_news)
                                buffer_news_emb = buffer_news_emb.detach().cpu().numpy()
                                all_node_embed.extend(list(buffer_news_emb))
                                all_node_meta.extend([meta_body[node] for node in export_news])
                                del buffer_news_emb
                            export_buffer = []

                    # export last buffer
                    if len(export_buffer) > 0:
                        export_news = [n for n in export_buffer if n in graph_sage_walker.news_labels]
                        #export_not_news = [n for n in export_buffer if n not in graph_sage_walker.news_labels]
                        if len(export_news) > 0:
                            _, _, buffer_news_emb, _, _ = infer_news_emb(
                                export_news)
                            buffer_news_emb = buffer_news_emb.detach().cpu().numpy()
                            all_node_embed.extend(list(buffer_news_emb))
                            all_node_meta.extend([meta_body[node] for node in export_news])
                    
                    all_node_embed = np.vstack(all_node_embed)
                    writer.add_embedding(all_node_embed, tag='node embedding', metadata=all_node_meta,
                                         global_step=global_step, metadata_header=meta_header)
                    
                    pca = PCA(n_components=2)
                    
                    all_node_embed = pca.fit_transform(all_node_embed)
                    all_node_embed = pd.DataFrame(all_node_embed)
                    all_node_embed.columns = ['P1', 'P2']

                    kmeans = KMeans(n_clusters=2).fit(all_node_embed)            
                    y_pred = kmeans.labels_

            
                    plt.scatter(all_node_embed['P1'], all_node_embed['P2'], c=y_pred, cmap='Paired')
                    plt.title("Clusters determined by KMeans")

                    plt.show()
                    
                    all_node_meta = [1 if meta[3] == 'news_real' else 0 for meta in all_node_meta]
                    print(v_measure_score(all_node_meta, y_pred))
                                        
                    del all_node_embed
                #best_evaluator = new_best_evaluator
    writer.close()
    # my part ends here


def eval_fn(dev_nodes, graph_sage_walker, graph_sage, news_classifier, n_stances, embed_size,
            metrics, global_step,
            writer, device, tag="validate", cutoff_range=None, return_attn=False):
    graph_sage.eval()
    news_classifier.eval()
    dev_sources_emb_batch, dev_news_emb_batch, dev_engage_user_emb_batch, dev_engage_stances_tensor, \
        dev_engage_ts_tensor, dev_news_labels_tensor, masked_attn_batch, dev_news_labels_batch = \
        preprocess_news_classification_data(graph_sage, graph_sage_walker, dev_nodes, n_stances,
                                            embed_size, device, cutoff_range, test=True)
    # we don't need the news embeddings here
    dev_news_logit_batch, output_attention, _ = news_classifier(dev_news_emb_batch, dev_sources_emb_batch,
                                                             dev_engage_user_emb_batch, dev_engage_stances_tensor,
                                                             dev_engage_ts_tensor, masked_attn_batch)
    dev_news_loss = graph_sage_walker.compute_news_loss(dev_news_logit_batch, dev_news_labels_tensor)

    dev_news_logit = dev_news_logit_batch.detach().cpu().numpy()
    dev_evaluator = Evaluator(dev_news_logit, dev_news_labels_batch)
    validate_result = dev_evaluator.evaluate(metrics)
    validate_result["loss"] = float(dev_news_loss.detach().cpu())
    print(validate_result)

    if writer is not None:
        writer.add_scalars(tag, validate_result, global_step)
    if return_attn:
        return dev_evaluator, output_attention
    return dev_evaluator


def preprocess_news_classification_data(graph_sage, graph_sage_walker, nodes_batch, n_stances, embed_size,
                                        device, cutoff_range=None, return_user_batch=False, test=False):
    source_batch, news_batch, engage_users_batch, engage_stances_batch, engage_ts_batch, \
        masked_attn_batch, news_labels_batch = \
        graph_sage_walker.fetch_news_classification(nodes_batch, n_stances, cutoff_range)
    news_labels_tensor = torch.LongTensor(news_labels_batch).to(device)
    engage_stances_tensor = torch.FloatTensor(engage_stances_batch).to(device)
    engage_ts_tensor = torch.FloatTensor(engage_ts_batch).to(device)
    engage_masked_attn_tensor = torch.FloatTensor(masked_attn_batch).to(device)

    news_emb_batch, sources_emb_batch = graph_sage(news_batch, test=test), graph_sage(source_batch, test=test)
    engage_user_emb_batch = [graph_sage(e_users, test=test) if len(e_users) > 0
                             else torch.zeros(1, embed_size).to(device) for e_users in engage_users_batch]
    for i, user_list in enumerate(engage_user_emb_batch):
        user_list = user_list[:graph_sage_walker.max_engages]
        if len(user_list) < graph_sage_walker.max_engages:
            padding_mtx = torch.zeros((graph_sage_walker.max_engages - len(user_list), embed_size)).to(device)
            engage_user_emb_batch[i] = torch.cat([user_list, padding_mtx], dim=0)
    engage_user_emb_batch = torch.stack(engage_user_emb_batch, dim=0)
    if not return_user_batch:
        return sources_emb_batch, news_emb_batch, engage_user_emb_batch, engage_stances_tensor, \
               engage_ts_tensor, news_labels_tensor, engage_masked_attn_tensor, news_labels_batch
    else:
        return sources_emb_batch, news_emb_batch, engage_user_emb_batch, engage_stances_tensor, \
               engage_ts_tensor, news_labels_tensor, engage_masked_attn_tensor, news_labels_batch, engage_users_batch

